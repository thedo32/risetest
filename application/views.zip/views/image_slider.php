
<div class="slideshow-container-img">    
    <div class="prev" onclick="plusSlides(-1)">&#10094;</div>
    <div class="next" onclick="plusSlides(1)">&#10095;</div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo1.png");?>" style="width:80%"><br>
        Semburatnya nan jingga Berkelumat dengan hitam Membaur dengan gelap Lenyap bersama 
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo2.png");?>" style="width:80%"><br>
        Kulepaskan pandanganku Jauh ke Ujung lautan ke Ujung pelangi Betapa luas alam semesta
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo3.png");?>" style="width:80%"><br>
        Deru ombak menghantam bebatuan Bisikan angin memecahkan suasana pilu Terlebih lagi ada cahaya indah di hadapan
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo4.png");?>" style="width:80%"><br>
        Mendengar suara deburan ombak jiwa yang lelah tidur nyenyak diiringi nyanyian alam sungguh indah sangat menawan
    </div>
	<div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo5.png");?>" style="width:80%"><br>
        Semburatnya nan jingga Berkelumat dengan hitam Membaur dengan gelap Lenyap bersama 
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo6.png");?>" style="width:80%"><br>
        Kulepaskan pandanganku Jauh ke Ujung lautan ke Ujung pelangi Betapa luas alam semesta
    </div>
	<div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo7.png");?>" style="width:80%"><br>
        Deru ombak menghantam bebatuan Bisikan angin memecahkan suasana pilu Terlebih lagi ada cahaya indah di hadapan
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo8.png");?>" style="width:80%"><br>
        Mendengar suara deburan ombak jiwa yang lelah tidur nyenyak diiringi nyanyian alam sungguh indah sangat menawan
    </div>
	
    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo9.png");?>" style="width:80%"><br>
        Deru ombak menghantam bebatuan Bisikan angin memecahkan suasana pilu Terlebih lagi ada cahaya indah di hadapan
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo10.png");?>" style="width:80%"><br>
        Mendengar suara deburan ombak jiwa yang lelah tidur nyenyak diiringi nyanyian alam sungguh indah sangat menawan
    </div>
	 <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo11.png");?>" style="width:80%"><br>
        Deru ombak menghantam bebatuan Bisikan angin memecahkan suasana pilu Terlebih lagi ada cahaya indah di hadapan
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/taluakbuo12.png");?>" style="width:80%"><br>
        Mendengar suara deburan ombak jiwa yang lelah tidur nyenyak diiringi nyanyian alam sungguh indah sangat menawan
    </div>
</div>

<script>
    var slideImgIndex = 0;
    var slides = document.getElementsByClassName("mySlidesImg");
    showSlidesImg();
</script>



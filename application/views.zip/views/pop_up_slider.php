
<div class="slideshow-container-pop">    
    <div class="prev" onclick="plusSlidesPop(-1)">&#10094;</div>
    <div class="next" onclick="plusSlidesPop(1)">&#10095;</div>

    <div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-eko-wisata-mangrove-per-perahu')?>" > 	
			<img src="<?php echo base_url ("/storage/app/public/images/slider/mangrove_perahu.png");?>" style="width:80%"><br>
        </a>
    </div>

    <div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-eko-wisata-mangrove-per-orang')?>" >
			<img src="<?php echo base_url ("/storage/app/public/images/slider/mangrove_orang.png");?>" style="width:80%"><br>
		</a> 
	</div>

	<div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-paket-snorkling-kupi-batigo')?>" >
		<img src="<?php echo base_url ("/storage/app/public/images/slider/snorkle.png");?>" style="width:80%"><br>
        </a>
    </div>

    <div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-paket-snorkling-kolam-hiu')?>" >
		<img src="<?php echo base_url ("/storage/app/public/images/slider/hiu_snorkle.png");?>" style="width:80%"><br>
        </a>
    </div>

	<div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-paket-berkemah')?>">
		<img src="<?php echo base_url ("/storage/app/public/images/slider/kemah.png");?>" style="width:80%"><br>
        </a>
    </div>

	 <div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-paket-memancing-area-dekat')?>" >
		<img src="<?php echo base_url ("/storage/app/public/images/slider/mancing_dekat.png");?>" style="width:80%"><br>
        </a>
    </div>

	<div class="mySlidesPop">
		<a href="<?php echo site_url('taluak/view/wisata-kupi-batigo-paket-memancing-area-dekat')?>" >
			<img src="<?php echo base_url ("/storage/app/public/images/slider/mancing_jauh.png");?>" style="width:80%"><br>
        </a>
    </div>
</div>

<script>
    var slidePopIndex = 0;
    var slidesPop = document.getElementsByClassName("mySlidesPop");
    showSlidesPop();
</script>


